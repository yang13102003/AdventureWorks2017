import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
file_path = r'D:\CurrentTopic\three.csv'
data = pd.read_csv(file_path)

# Group the data by Territory and MostFavoriteProduct, summing up TotalOrder
grouped_data = data.groupby(['Territory', 'MostFavoriteProduct'])['TotalOrder'].sum().unstack()

# Plot the data
grouped_data.plot(kind='bar', stacked=True, figsize=(10, 6))
plt.title('Customer Preferences Across Market Regions')
plt.xlabel('Market Regions (Territory)')
plt.ylabel('Total Orders')
plt.legend(title='Most Favorite Product', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()
"""
Analyze: 
The "AWC Logo Cap" dominates in Southwest US and Canada, each recording over 14,000 total orders. These regions show a clear preference for branded headwear, possibly reflecting lifestyle or climate-related needs.
The "Water Bottle - 30 oz" is the most popular product in Northwest US, Australia, and Germany, suggesting a focus on reusable and sustainable products in these regions.
The "Long-Sleeve Logo Jersey" has the highest popularity in the Northeast US but lags significantly compared to the other products across other regions.
Regions such as Central US, France, and Southeast US exhibit lower total orders, regardless of the product, indicating either smaller markets or less engagement.
"""