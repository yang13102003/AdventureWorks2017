import pandas as pd
import matplotlib.pyplot as plt

# Load the provided CSV file
file_path = r"D:\CurrentTopic\two.csv"

  # Replace with your actual file path
df = pd.read_csv(file_path)

# Filter data for US territories
us_data = df[df['Territory'].str.contains('-US')]

# Group by YearlyIncome and Territory for US territories
us_grouped = us_data.groupby(['YearlyIncome', 'Territory'])['AvgSpending'].mean().reset_index()

# Plotting the chart for US territories
plt.figure(figsize=(14, 8))
for territory in us_grouped['Territory'].unique():
    subset = us_grouped[us_grouped['Territory'] == territory]
    plt.plot(subset['YearlyIncome'], subset['AvgSpending'], marker='o', label=territory)

plt.title('Trend of Average Spending Across Yearly Income Ranges by US Territories')
plt.xlabel('Yearly Income Range')
plt.ylabel('Average Spending')
plt.xticks(rotation=45)
plt.legend(title='US Territories', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

# Filter data for territories outside the US
non_us_data = df[~df['Territory'].str.contains('-US')]

# Group by YearlyIncome and Territory for non-US territories
non_us_grouped = non_us_data.groupby(['YearlyIncome', 'Territory'])['AvgSpending'].mean().reset_index()

# Plotting the chart for non-US territories
plt.figure(figsize=(14, 8))
for territory in non_us_grouped['Territory'].unique():
    subset = non_us_grouped[non_us_grouped['Territory'] == territory]
    plt.plot(subset['YearlyIncome'], subset['AvgSpending'], marker='o', label=territory)

plt.title('Trend of Average Spending Across Yearly Income Ranges by Non-US Territories')
plt.xlabel('Yearly Income Range')
plt.ylabel('Average Spending')
plt.xticks(rotation=45)
plt.legend(title='Non-US Territories', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
"""
Analyze:

Chart 1 : Spending increases consistently with income across all countries, indicating a direct correlation between income and purchasing power.
Germany exhibits the highest spending in the top income bracket (>100,000), reaching 1,385, while Australia has the lowest (744) in the same bracket.
Canada shows a steady increase across all income ranges, with no significant dips, while the UK and Germany see steep increases in the highest income categories.
France demonstrates a steady climb up to $75,000-$100,000 income but drops sharply in the highest income range, possibly indicating market saturation or reduced high-income customer representation.

Chart 2: The "AWC Logo Cap" dominates as the most popular product in Southwest US and Canada, both exceeding 12,000 orders, reflecting strong regional demand for branded headwear.
Water bottles are most favored in regions like Northwest US, Australia, and the UK, indicating different preferences and utility trends compared to other markets.
Germany and Central US have a lower total number of orders overall, highlighting potential growth opportunities.
The "Long-Sleeve Logo Jersey" sees the highest demand in Northeast US, though it remains less dominant compared to other products in different regions.

"""
