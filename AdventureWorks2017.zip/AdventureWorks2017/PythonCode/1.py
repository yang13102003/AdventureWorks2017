import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
file_path = "CustomerDemographic.csv"  # Replace with your CSV file path
data = pd.read_csv(file_path)

# Group data by Territory and Gender for visualization
grouped_data = data.groupby(['Territory', 'Gender']).mean()

# Chart 1: Average Age by Gender Across Regions
plt.figure(figsize=(10, 6))
grouped_data['AvgAge'].unstack().plot(kind='bar', stacked=False, ax=plt.gca())
plt.title('Average Age by Gender Across Regions')
plt.xlabel('Territory')
plt.ylabel('Average Age')
plt.legend(title='Gender')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Chart 2: Average Total Purchase YTD by Gender Across Regions
plt.figure(figsize=(10, 6))
grouped_data['AvgTotalPurchaseYTD'].unstack().plot(kind='bar', stacked=False, ax=plt.gca())
plt.title('Average Total Purchase YTD by Gender Across Regions')
plt.xlabel('Territory')
plt.ylabel('Avg Total Purchase YTD ($)')
plt.legend(title='Gender')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Chart 3: Total Number of Customers by Gender Across Regions
plt.figure(figsize=(10, 6))
data.pivot_table(index='Territory', columns='Gender', values='TotalCustomers', aggfunc='sum').plot(kind='bar', stacked=True, ax=plt.gca())
plt.title('Total Number of Customers by Gender Across Regions')
plt.xlabel('Territory')
plt.ylabel('Total Customers')
plt.legend(title='Gender')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

"""
Analyze: 

Chart 1: The Aerage age across regions is consistently high, with minimal differences between genders. Both male and female customers have similar average ages, indicating no significant demographic variations.
Regions such as Australia and the UK show almost identical age averages between genders, emphasizing a balanced age demographic.
The lack of substantial age variation suggests that this demographic factor may not play a significant role in differentiating target audiences.

Chart 2: Australia stands out with the highest average purchase values for both genders, while regions like Central US and Southeast US exhibit lower spending.
Females tend to outspend males in several regions, notably Germany and France, while in others, such as the UK and Southwest US, males spend slightly more.
The consistent spending across genders within a region suggests shared economic factors but highlights regional preferences influencing purchase behavior.

Chart 3 : Australia and the Northwest US have the highest total customer counts, indicating strong market presence.
Gender distribution varies by region: males dominate in regions like Southwest US, while other areas, such as Germany, show more balanced gender participation.
Smaller regions like Central US and Southeast US have much lower customer numbers, suggesting untapped or underperforming markets.
"""