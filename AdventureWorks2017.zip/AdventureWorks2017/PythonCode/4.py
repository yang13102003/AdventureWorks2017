import pandas as pd
import matplotlib.pyplot as plt

# Replace with your extracted CSV file path
file_path = r"D:\CurrentTopic\four.csv"

# Load the CSV data into a DataFrame
df = pd.read_csv(file_path)

# Check column names to ensure correctness
print("Columns in CSV:", df.columns)

# Sort data by AvgReturn, then reorder US territories to stay together
df["IsUS"] = df["Territory"].str.contains("-US")  # Add a helper column to identify US territories
df = df.sort_values(by=["IsUS", "AvgReturnAmount"], ascending=[False, False])  # Sort with US territories together

# Plot the chart
plt.figure(figsize=(10, 6))
bars = plt.barh(df["Territory"], df["AvgReturnAmount"], color="skyblue")
for bar, val in zip(bars, df["AvgReturnAmount"]):
    plt.text(val + 0.1, bar.get_y() + bar.get_height() / 2, f"{val:.2f}", va="center", fontsize=10)

plt.title("Average of Customer Return Amount Across Territories", fontsize=14)
plt.xlabel("Average Return Amount", fontsize=12)
plt.ylabel("Territory", fontsize=12)
plt.tight_layout()
plt.show()

'''
Analyze:
Highest Return Averages:

Northeast-US (6.18), Central-US (5.65), and Southeast-US (5.32) have the highest average return amounts.
Moderate Return Averages:

Canada-CA (2.43) and Australia-AU (1.89) lead among non-US territories.
Lowest Return Averages:

European regions like France-FR (1.44), Germany-DE (1.45), and United Kingdom-GB (1.65) have consistently low averages, along with US territories like Northwest-US (1.34) and Southwest-US (1.37).
US Territories Show High Variability:

A large gap exists between the highest (Northeast-US) and lowest (Northwest-US) average returns within the US.

'''