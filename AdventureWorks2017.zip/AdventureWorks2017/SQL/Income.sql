CREATE TABLE CustomerIncomeSummary_Reformatted (
    TerritoryID INT,
    TotalCustomers_0_25000 INT,
    TotalCustomers_50001_75000 INT,
    TotalCustomers_75001_100000 INT,
    TotalCustomers_GreaterThan100000 INT
);
INSERT INTO CustomerIncomeSummary_Reformatted (TerritoryID, TotalCustomers_0_25000, TotalCustomers_50001_75000, 
                                               TotalCustomers_75001_100000, TotalCustomers_GreaterThan100000)
SELECT 
    TerritoryID,
    ISNULL([0-25000], 0) AS TotalCustomers_0_25000,
    ISNULL([50001-75000], 0) AS TotalCustomers_50001_75000,
    ISNULL([75001-100000], 0) AS TotalCustomers_75001_100000,
    ISNULL([greater than 100000], 0) AS TotalCustomers_GreaterThan100000
FROM (
    SELECT 
        a.TerritoryID,
        cd.YearlyIncome,
        COUNT(cd.CustomerDemoDimID) AS TotalCustomers
    FROM 
        CustomerDemographicDimensions cd
    JOIN 
        AddressDimension a 
        ON cd.CustomerDemoDimID = a.AddressDimID -- Adjust join condition as needed
    GROUP BY 
        a.TerritoryID, cd.YearlyIncome
) AS SourceTable
PIVOT (
    SUM(TotalCustomers)
    FOR YearlyIncome IN ([0-25000], [50001-75000], [75001-100000], [greater than 100000])
) AS PivotTable
ORDER BY TerritoryID;