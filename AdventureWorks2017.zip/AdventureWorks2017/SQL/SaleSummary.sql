CREATE TABLE TerritorySalesSummary (
    TerritoryID INT PRIMARY KEY,
    TotalOrders INT,
    TotalSalesAmount DECIMAL(18, 2),
);
INSERT INTO TerritorySalesSummary (TerritoryID, TotalOrders, TotalSalesAmount)
SELECT 
    sh.TerritoryID,
    COUNT(DISTINCT sh.SalesOrderID) AS TotalOrders,
    SUM(sh.SubTotal) AS TotalSalesAmount
FROM 
    Sales_HeaderDetailDimension sh
JOIN 
    CustomerTerritoryDimension ct 
    ON sh.TerritoryID = ct.TerritoryID
GROUP BY 
    sh.TerritoryID;