-- Step 1: Create the Table
CREATE TABLE CustomerReturnRateSummary (
    TerritoryID INT PRIMARY KEY,
    AvgReturn DECIMAL(10, 2)
);

-- Step 2: Insert Data with AvgReturn Calculation
INSERT INTO CustomerReturnRateSummary (TerritoryID, AvgReturn)
SELECT 
    sh.TerritoryID,
    CAST(AVG(CAST(ReturnCounts.NumberOfReturns AS FLOAT)) AS DECIMAL(10, 2)) AS AvgReturn
FROM 
    (
        SELECT 
            CustomerID,
            TerritoryID,
            COUNT(DISTINCT SalesOrderID) AS NumberOfReturns
        FROM 
            Sales_HeaderDetailDimension
        GROUP BY 
            CustomerID, TerritoryID
    ) AS ReturnCounts
JOIN 
    Sales_HeaderDetailDimension sh 
    ON sh.TerritoryID = ReturnCounts.TerritoryID
GROUP BY 
    sh.TerritoryID
ORDER BY 
    sh.TerritoryID
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY; -- Ensure only 10 rows are inserted